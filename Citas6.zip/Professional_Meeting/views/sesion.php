<?php
require_once '../assets/conexion/servidor.php';
$conexion->query("SET NAMES 'utf8'");
$conexion=mysqli_connect($host,$db_username,$db_password,$db_name);
session_start();



if(isset($_SESSION['login_user_sys'])){
$usuario = $_SESSION['login_user_sys'];

 switch($usuario){ 
  
  case 'Administrador': echo "<script type='text/javascript'>
        window.location='citas1.1.php'
        </script>"; // Redirecciona a la pagina de talleres
        break;

   case 'Usuario': 

          echo "<script type='text/javascript'>
          window.location='citas_usuario.php'
          </script>"; // Redirecciona a la pagina de talleres
    
          break;

 }
  }


   
   

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<header>
    <title>Talleres</title>
</header>


<link rel="stylesheet" href="../assets/css/estilo_sesion.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">



<?php include 'header_sesion.php'; ?>

</head>
<body>
    


<div class="fondo">





<section class="vh-30" >
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card shadow-2-strong" style="border-radius: 1rem;">
          <div class="card-body p-5 text-center">
           <form action="" method="POST">
            <h3 class="mb-5">Iniciar sesión</h3>

           <!--<div class="form-outline mb-4">
              <input type="email" id="typeEmailX-2" class="form-control form-control-lg" />
              <label class="form-label" for="typeEmailX-2">Email</label>
            </div>-->

            <div class="form-outline mb-4">
            <!--<label class="form-label" for="typePasswordX">Contraseña</label>-->
              <input type="password" id="typePasswordX" name="typePasswordX" class="form-control form-control-lg" placeholder="Contraseña" autocomplete="off">
             
            </div>

            <!-- Checkbox 
            <div class="form-check d-flex justify-content-start mb-4">
              <input class="form-check-input" type="checkbox" value="" id="form1Example3" />
              <label class="form-check-label" for="form1Example3"> recordar contraseña </label>
            </div>-->
            

            <button class="btn btn-primary btn-lg btn-block" type="submit" name="iniciar_sesion" >Entrar</button>

            <hr class="my-4">

            <!--<button class="btn btn-lg btn-block btn-primary" style="background-color: #dd4b39;"
              type="submit"><i class="fab fa-google me-2"></i> Sign in with google</button>
            <button class="btn btn-lg btn-block btn-primary mb-2" style="background-color: #3b5998;"
              type="submit"><i class="fab fa-facebook-f me-2"></i>Sign in with facebook</button>-->
              </form>
              <div class="alert alert-danger error_contra" id="error_contra" role="alert" hidden="true">
  Error, no se pudo iniciar sesión con esa <span class="alert-link">contraseña</span>.
</div>
<div class="alert alert-danger error_contra" id="error_contra_vacio" role="alert" hidden="true">
  Error, debe de ingresar una <span class="alert-link">contraseña</span>.
</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<?php


if(isset($_POST['iniciar_sesion'])){

$contra = $_POST['typePasswordX'];

if(!empty($contra)){

$contra_encrypt = sha1($_POST['typePasswordX']);



$encontrar_cuenta = "SELECT * FROM cuentas_usuarios WHERE Contra='$contra' OR Contra='$contra_encrypt'";

$cuenta_encontrada = mysqli_query($conexion,$encontrar_cuenta);

if(mysqli_num_rows($cuenta_encontrada)>0){

while($cuenta = mysqli_fetch_array($cuenta_encontrada)){

  $tipo_cuenta = $cuenta['Usuario'];

}

switch($tipo_cuenta){

  case 'Administrador':  
    // Iniciando sesion
    $_SESSION['login_user_sys']=$tipo_cuenta;
  $_SESSION["timeout"] = time();

  echo "<script type='text/javascript'>
  window.location='citas1.1.php'
  </script>";

  break;

  case 'Usuario': 
    // Iniciando sesion
    $_SESSION['login_user_sys']=$tipo_cuenta;  
  $_SESSION["timeout"] = time();

  echo "<script type='text/javascript'>
  window.location='citas_usuario.php'
  </script>";

  break;

  default:  break;

}

}else{
  echo "<script> var error = document.getElementById('error_contra'); error.hidden = false; </script>";
}

}else{
  echo "<script> var error = document.getElementById('error_contra_vacio'); error.hidden = false; </script>";
}
}

?>




<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>



</div><script type="text/javascript" src="https://mdbcdn.b-cdn.net/wp-content/themes/mdbootstrap4/docs-app/js/dist/mdb5/standard/core.min.js"></script>
<script type="text/javascript" src="https://mdbcdn.b-cdn.net/wp-content/themes/mdbootstrap4/docs-app/js/dist/search/search.min.js"></script>
<script src="https://mdbcdn.b-cdn.net/wp-content/themes/mdbootstrap4/docs-app/js/dist/main.min.js"></script>
</body>
</html>