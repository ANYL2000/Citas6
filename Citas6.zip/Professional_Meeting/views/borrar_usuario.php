<?php

include '../assets/conexion/servidor.php';

session_start();// Iniciando Sesion



if(!isset($_SESSION['login_user_sys'])){

//mysqli_close($conexion); // Cerrando la conexion
echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>"; // Redirecciona a la pagina de sesion
}else{
$usuario = $_SESSION['login_user_sys'];

if($usuario!='Administrador'){
  session_destroy();
  echo "<script type='text/javascript'>
      window.location='sesion.php'
      </script>";

}

}

$idusuario = $_GET['id'];
$tallerista_seleccionado = $_GET['tallerista'];
 $taller_seleccionado = $_GET['taller'];
 $calendario_seleccionado = $_GET['calendario'];
 $hora_seleccionado = $_GET['hora'];


$con=mysqli_connect($host,$db_username,$db_password,$db_name);
$con->query("SET NAMES 'utf8'");
$lugares_talleres = "SELECT * FROM mostrar_cita WHERE Calendario = '$calendario_seleccionado' AND 
    NombreEspecialidad = '$taller_seleccionado' AND NombreEspecialista = '$tallerista_seleccionado' AND 
    Hora = '$hora_seleccionado'";

$filas_talleres = mysqli_query($con,$lugares_talleres);


$conexion->query("SET NAMES 'utf8'");

mysqli_query($conexion, "DELETE FROM pacientes_reservados WHERE idUsuarios = $idusuario");

if($conexion){



    

    $conexion->query("UPDATE mostrar_cita SET Reservado= 'No' WHERE Calendario = '$calendario_seleccionado' AND 
NombreEspecialidad = '$taller_seleccionado' AND NombreEspecialista = '$tallerista_seleccionado'  AND 
Hora = '$hora_seleccionado'");

}

echo "<script type='text/javascript'>
window.location='citas1.2.php?tallerista=$tallerista_seleccionado&taller=$taller_seleccionado&calendario=$calendario_seleccionado&hora=$hora_seleccionado'
</script>";
//echo "<script> window.history.back();</script>";


?>